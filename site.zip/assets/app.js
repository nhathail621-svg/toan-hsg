/* ===== HSG Toán Hà Tĩnh 2027 — app.js ===== */
(function () {
  'use strict';
  var KEY = 'hsg11_progress_v1', KEYFC = 'hsg11_flash_v1', KEYDAY = 'hsg11_days_v1';

  /* ---------- storage an toàn (khung xem trước có thể chặn localStorage) ---------- */
  var ST = (function () {
    try { window.localStorage.setItem('__t', '1'); window.localStorage.removeItem('__t'); return window.localStorage; }
    catch (e) { return null; }
  })();
  function read(k, def) {
    try { var v = ST && ST.getItem(k); return v ? JSON.parse(v) : def; } catch (e) { return def; }
  }
  function write(k, v) { try { if (ST) ST.setItem(k, JSON.stringify(v)); } catch (e) {} }

  var P = {
    s: new Set(read(KEY, [])),
    has: function (id) { return this.s.has(String(id)); },
    add: function (id) { this.s.add(String(id)); write(KEY, Array.from(this.s)); paintMini(); },
    del: function (id) { this.s.delete(String(id)); write(KEY, Array.from(this.s)); paintMini(); },
    count: function () { return this.s.size; }
  };
  window.HSG = { P: P, read: read, write: write, ST: ST };

  /* ---------- Lục Nhãn: quầng sáng theo con trỏ trên hero ---------- */
  var hero = document.getElementById('hero'), glow = document.getElementById('eyeGlow');
  if (hero && glow && window.matchMedia && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    hero.addEventListener('mousemove', function (e) {
      var r = hero.getBoundingClientRect();
      glow.style.left = (e.clientX - r.left) + 'px';
      glow.style.top = (e.clientY - r.top) + 'px';
    });
  }

  /* ---------- menu mobile ---------- */
  var burger = document.getElementById('burger');
  if (burger) burger.onclick = function () { document.body.classList.toggle('menu'); };
  var scrim = document.querySelector('.scrim');
  if (scrim) scrim.onclick = function () { document.body.classList.remove('menu'); };

  /* ---------- mini tiến độ ở sidebar ---------- */
  function paintMini() {
    var el = document.getElementById('miniCount'), bar = document.getElementById('miniBar');
    if (!el) return;
    el.textContent = P.count().toLocaleString('vi-VN') + ' bài đã làm';
    if (bar) bar.style.width = Math.min(100, 100 * P.count() / 3014) + '%';
  }
  paintMini();

  /* ---------- khung xem trước: nhắc lưu ý ---------- */
  if (!ST) {
    var n = document.createElement('div');
    n.className = 'note';
    n.innerHTML = '<b>Chế độ xem trước:</b> tiến độ chỉ lưu tạm trong phiên. Mở bằng trình duyệt thật (hoặc bản online) là lưu vĩnh viễn.';
    var host = document.querySelector('main .wrap');
    if (host) host.insertBefore(n, host.firstChild);
  }

  /* ================= KHO BÀI ================= */
  var list = document.getElementById('qlist');
  if (list && window.BANK) {
    var D = window.BANK, TOP = window.TOPICS, PAGE = 80, shown = 0, F = [];
    var $ = function (s) { return document.querySelector(s); };
    var el = {
      q: $('#fq'), topic: $('#ftopic'), diff: $('#fdiff'), sort: $('#fsort'),
      star: $('#fstar'), sol: $('#fsol'), real: $('#freal'), todo: $('#ftodo'),
      stat: $('#stat'), more: $('#more'), list: list
    };
    var DLAB = ['', 'Cơ bản', 'Vận dụng', 'Vận dụng cao'];

    function pct(a, b) { if (!a) return 0; return b ? (a * 100 / b < 9.95 ? (100 * a / b).toFixed(1) : Math.round(100 * a / b)) : 0; }

    function filter() {
      var q = (el.q.value || '').toLowerCase().trim(), t = el.topic.value, d = el.diff.value;
      var star = el.star.checked, sol = el.sol.checked, real = el.real.checked, todo = el.todo.checked;
      F = D.filter(function (r) {
        if (t !== 'all' && TOP[r[1]][0] !== t) return false;
        if (d !== 'all' && String(r[3]) !== d) return false;
        if (star && !r[2]) return false;
        if (sol && !r[4]) return false;
        if (real && !r[5]) return false;
        if (todo && P.has(r[0])) return false;
        if (q && (r[6] + ' ' + r[7]).toLowerCase().indexOf(q) < 0) return false;
        return true;
      });
      var s = el.sort.value;
      if (s === 'id') F = F.slice().sort(function (a, b) { return String(a[0]).localeCompare(String(b[0])); });
      if (s === 'hard') F = F.slice().sort(function (a, b) { return b[3] - a[3] || b[2] - a[2]; });
      shown = 0; el.list.innerHTML = ''; more(); stat();
      ['star', 'sol', 'real', 'todo'].forEach(function (k) {
        el[k].parentNode.classList.toggle('on', el[k].checked);
      });
    }

    function stat() {
      var doneStar = 0, starTot = 0;
      for (var i = 0; i < D.length; i++) { if (D[i][2]) { starTot++; if (P.has(D[i][0])) doneStar++; } }
      el.stat.innerHTML = 'Hiện <b>' + F.length.toLocaleString('vi-VN') + '</b> / ' + D.length.toLocaleString('vi-VN') +
        ' bài · đã làm <b>' + P.count().toLocaleString('vi-VN') + '</b> (' + pct(P.count(), D.length) + '%) · ★ <b>' +
        doneStar + '/' + starTot + '</b>';
    }

    function card(r) {
      var t = TOP[r[1]], done = P.has(r[0]);
      var a = document.createElement('article');
      a.className = 'q' + (r[2] ? ' star' : '') + (done ? ' done' : '');
      a.innerHTML =
        '<div class="qhead">' +
          '<span class="kk k' + t[2] + '">' + t[2] + '</span>' +
          '<span class="qid">#' + r[0] + '</span>' +
          '<span class="tag">' + t[1] + '</span>' +
          '<span class="tag' + (r[3] === 3 ? ' red' : '') + '">' + (DLAB[r[3]] || '') + '</span>' +
          (r[2] ? '<span class="tag gold">★ trọng tâm</span>' : '') +
          (r[5] ? '<span class="tag blue">thực tế</span>' : '') +
          (r[4] ? '' : '<span class="tag">chưa có lời giải</span>') +
          '<label class="chk"><input type="checkbox"' + (done ? ' checked' : '') + '> Đã làm</label>' +
        '</div>' +
        '<div class="qtext">' + r[6] + '</div>' +
        (r[7] && r[7].length > 120
          ? '<details><summary>Lời giải / hướng dẫn</summary><div class="sol">' + r[7] + '</div></details>'
          : (r[2] ? '<div class="qhead" style="margin:8px 0 0"><a class="tag gold" href="loigiai.html">★ Lời giải chi tiết ở mục Lời giải ★</a></div>'
                  : (r[7] ? '<details><summary>Gợi ý</summary><div class="sol">' + r[7] + '</div></details>' : ''))) +
        '<div class="qhead" style="margin:8px 0 0"><span class="tag">' + r[8] + '</span></div>';
      a.querySelector('.chk input').onchange = function (e) {
        if (e.target.checked) { P.add(r[0]); a.classList.add('done'); } else { P.del(r[0]); a.classList.remove('done'); }
        stat();
        if (el.todo.checked) { a.remove(); }
      };
      return a;
    }

    function more() {
      var frag = document.createDocumentFragment(), end = Math.min(shown + PAGE, F.length);
      for (var i = shown; i < end; i++) frag.appendChild(card(F[i]));
      el.list.appendChild(frag); shown = end;
      if (shown >= F.length) {
        el.more.style.display = 'none';
        if (!F.length) el.list.innerHTML = '<div class="empty">Không có bài nào khớp bộ lọc. Bỏ bớt điều kiện đi nhé.</div>';
      } else {
        el.more.style.display = 'inline-flex';
        el.more.textContent = 'Tải thêm ' + Math.min(PAGE, F.length - shown) + ' bài (còn ' + (F.length - shown).toLocaleString('vi-VN') + ')';
      }
    }

    [el.q, el.topic, el.diff, el.sort, el.star, el.sol, el.real, el.todo].forEach(function (e) {
      e.addEventListener(e.type === 'search' && e.tagName === 'INPUT' ? 'input' : 'change', filter);
    });
    el.more.onclick = more;

    /* tham số URL: ?star=1&topic=T01&todo=1 */
    var qs = new URLSearchParams(location.search);
    if (qs.get('star') === '1') el.star.checked = true;
    if (qs.get('todo') === '1') el.todo.checked = true;
    if (qs.get('topic')) el.topic.value = qs.get('topic');
    if (qs.get('diff')) el.diff.value = qs.get('diff');
    if (qs.get('sort')) el.sort.value = qs.get('sort');

    filter();

    document.addEventListener('keydown', function (e) {
      if (e.key === '/' && ['INPUT', 'SELECT', 'TEXTAREA'].indexOf(document.activeElement.tagName) < 0) {
        e.preventDefault(); el.q.focus();
      }
    });
  }

  /* ================= TIẾN ĐỘ ================= */
  var pt = document.getElementById('p-topics');
  if (pt && window.BANK) {
    var D2 = window.BANK, T2 = window.TOPICS;
    var all = D2.length, starT = 0, starD = 0, tDone = T2.map(function () { return 0; }), tAll = T2.map(function () { return 0; });
    D2.forEach(function (r) {
      tAll[r[1]]++;
      if (P.has(r[0])) tDone[r[1]]++;
      if (r[2]) { starT++; if (P.has(r[0])) starD++; }
    });
    document.getElementById('p-all').textContent = P.count().toLocaleString('vi-VN') + '/' + all.toLocaleString('vi-VN');
    document.getElementById('p-all-bar').style.width = (100 * P.count() / all) + '%';
    document.getElementById('p-star').textContent = starD + '/' + starT;
    document.getElementById('p-star-bar').style.width = (100 * starD / starT) + '%';
    pt.innerHTML = T2.map(function (t, i) {
      var p = tAll[i] ? Math.round(100 * tDone[i] / tAll[i]) : 0;
      return '<div style="margin:12px 0"><div style="display:flex;justify-content:space-between;gap:12px;align-items:center">' +
        '<span><span class="kk k' + t[2] + '">' + t[2] + '</span> <b style="font-size:14.6px">' + t[1] + '</b></span>' +
        '<span style="color:var(--mut);font-size:13px;font-weight:650">' + tDone[i] + '/' + tAll[i] + ' · ' + p + '%</span></div>' +
        '<div class="prog' + (t[2] === 'S' ? ' gold' : '') + '" style="margin-top:7px"><i style="width:' + p + '%"></i></div></div>';
    }).join('');
    var ex = document.getElementById('p-export');
    if (ex) ex.onclick = function () {
      var blob = new Blob([JSON.stringify(Array.from(P.s))], { type: 'application/json' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = 'tien_do_HSG11.json'; a.click();
    };
    var im = document.getElementById('p-import');
    if (im) im.onchange = function (e) {
      var f = e.target.files[0]; if (!f) return;
      var rd = new FileReader();
      rd.onload = function () {
        try { JSON.parse(rd.result).forEach(function (x) { P.add(x); }); location.reload(); }
        catch (err) { alert('Tệp không đúng định dạng.'); }
      };
      rd.readAsText(f);
    };
    var rs = document.getElementById('p-reset');
    if (rs) rs.onclick = function () {
      if (confirm('Xoá toàn bộ dấu "đã làm" trên máy này?')) { write(KEY, []); location.reload(); }
    };
  }

  /* ================= 15 PHÚT / NGÀY ================= */
  var daybar = document.getElementById('daybar');
  if (daybar) {
    var decks = Array.prototype.slice.call(document.querySelectorAll('.deck'));
    var daysDone = new Set(read(KEYDAY, []));
    var cur = read('hsg11_day_cur', 1);

    function showDay(n, scroll) {
      cur = n; write('hsg11_day_cur', n);
      decks.forEach(function (d) { d.classList.toggle('on', +d.dataset.day === n); });
      Array.prototype.forEach.call(daybar.querySelectorAll('button'), function (b) {
        b.classList.toggle('on', +b.dataset.day === n);
        b.classList.toggle('dn', daysDone.has(+b.dataset.day));
        if (scroll) { try { b.scrollIntoView({ block: 'nearest', inline: 'center' }); } catch (e) {} }
      });
      if (scroll) window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    daybar.innerHTML = decks.map(function (d, i) {
      return '<button data-day="' + (i + 1) + '">' + (i + 1) + '</button>';
    }).join('');
    daybar.onclick = function (e) {
      var b = e.target.closest('button'); if (b) showDay(+b.dataset.day);
    };
    var dbtn = document.getElementById('dayDone');
    if (dbtn) dbtn.onclick = function () {
      if (daysDone.has(cur)) daysDone.delete(cur); else daysDone.add(cur);
      write(KEYDAY, Array.from(daysDone));
      dbtn.textContent = daysDone.has(cur) ? '✓ Đã làm xong đề này' : 'Đánh dấu đã làm xong';
      dbtn.classList.toggle('ghost', daysDone.has(cur));
      showDay(cur, false);
    };
    var prev = document.getElementById('dayPrev'), next = document.getElementById('dayNext');
    if (prev) prev.onclick = function () { showDay(Math.max(1, cur - 1), true); };
    if (next) next.onclick = function () { showDay(Math.min(decks.length, cur + 1), true); };
    showDay(Math.min(Math.max(1, cur), decks.length), false);
    var lbl = document.getElementById('dayDone');
    if (lbl) { lbl.textContent = daysDone.has(cur) ? '✓ Đã làm xong đề này' : 'Đánh dấu đã làm xong'; lbl.classList.toggle('ghost', daysDone.has(cur)); }
  }

  /* ================= FLASHCARD ================= */
  var stage = document.getElementById('fcstage');
  if (stage && window.CARDS) {
    var cards = window.CARDS.slice();
    var known = new Set(read(KEYFC, []));
    var i = 0, onlyUnknown = false;

    function pool() {
      return cards.filter(function (c) { return !onlyUnknown || !known.has(c.n); });
    }
    function render() {
      var p = pool();
      var box = document.getElementById('fcard');
      if (!p.length) { box.innerHTML = '<div class="card"><h3>Hết thẻ 🎉</h3><p>Bạn đã đánh dấu thuộc cả ' + cards.length + ' thẻ. Bỏ lọc "chỉ thẻ chưa thuộc" để ôn lại toàn bộ.</p></div>'; paint(); return; }
      if (i >= p.length) i = 0;
      var c = p[i];
      box.className = 'fcard';
      box.innerHTML = '<div class="inner">' +
        '<div class="face front"><div class="lbl">THẺ ' + (i + 1) + '/' + p.length + ' · ' + c.group + ' · MỨC ' + c.tier + '</div>' +
        '<div class="sign">' + c.sign + '</div><div class="hint">Nhìn dấu hiệu → gọi tên vũ khí trong ≤ 20 giây · bấm để lật</div></div>' +
        '<div class="face back"><div class="row"><h4>Vũ khí</h4><div class="wpn">' + c.weapon + '</div></div>' +
        '<div class="row"><h4>Các bước</h4><div>' + c.steps + '</div></div>' +
        '<div class="row"><h4>Bẫy</h4><div class="trap">' + c.trap + '</div></div></div></div>';
      box.onclick = function (e) { if (e.target.closest('.back')) return; box.classList.toggle('flip'); };
      paint();
      var k = document.getElementById('fcKnown');
      if (k) k.checked = known.has(c.n);
    }
    function paint() {
      document.getElementById('fcCount').textContent = known.size + '/' + cards.length + ' thẻ đã thuộc';
      document.getElementById('fcBar').style.width = (100 * known.size / cards.length) + '%';
    }
    document.getElementById('fcNext').onclick = function () { i++; render(); };
    document.getElementById('fcPrev').onclick = function () { i = Math.max(0, i - 1); render(); };
    var kbox = document.getElementById('fcKnown');
    if (kbox) kbox.onchange = function () {
      var p = pool(); var c = p[i]; if (!c) return;
      if (kbox.checked) known.add(c.n); else known.delete(c.n);
      write(KEYFC, Array.from(known)); render();
    };
    var sh = document.getElementById('fcShuffle');
    if (sh) sh.onclick = function () {
      for (var j = cards.length - 1; j > 0; j--) { var k2 = Math.floor(Math.random() * (j + 1)); var tmp = cards[j]; cards[j] = cards[k2]; cards[k2] = tmp; }
      i = 0; render();
    };
    var ou = document.getElementById('fcUnknown');
    if (ou) ou.onchange = function () { onlyUnknown = ou.checked; i = 0; render(); };
    var gf = document.getElementById('fcGroup');
    if (gf) gf.onchange = function () {
      var g = gf.value;
      cards = window.CARDS.filter(function (c) { return g === 'all' || c.group === g; });
      known = new Set(Array.from(known)); i = 0; render();
    };
    render();
  }
})();
