/* Offline, conservative MathML formatter. It does not infer missing PDF structure. */
(function () {
  'use strict';
  var NS='http://www.w3.org/1998/Math/MathML';
  var targets='.qtext, .sol, .dq, .dsol, .legacy .de, .md, .fcard .front, .fcard .back';
  // Single-level nested parenthesis; restrictive identifiers keep prose like km/giờ intact.
  var atom='(?:(?:sin|cos|tan|cot|ln)\\s*[a-zA-Z][₀₁₂₃₄₅₆₇₈₉⁰¹²³⁴⁵⁶⁷⁸⁹0-9]*|[0-9]+(?:[.,][0-9]+)?(?:π|[a-zA-Z])?[⁰¹²³⁴⁵⁶⁷⁸⁹₀₁₂₃₄₅₆₇₈₉]*|π|[a-zA-Z](?:[₀₁₂₃₄₅₆₇₈₉⁰¹²³⁴⁵⁶⁷⁸⁹0-9])?|(?:sin|cos|tan|cot)[a-zA-Z]+)';
  var par='\\((?:[^()\\n]{1,90}|[^()\\n]{0,45}\\([^()\\n]{1,45}\\)[^()\\n]{0,45})\\)';
  var radical='√\\s*(?:'+par+'|'+atom+')';
  var part='(?:'+par+'|'+radical+'|'+atom+')';
  var expression=new RegExp('('+part+')\\s*/\\s*('+part+')|('+radical+')|\\b([CA])\\((\\d{1,3}),(\\d{1,3})\\)','g');
  var letter=/[\p{L}\p{N}_]/u;
  function el(n){return document.createElementNS(NS,n)}
  function isParen(s){return s[0]==='(' && s[s.length-1]===')'}
  function inner(s){return isParen(s)?s.slice(1,-1):s}
  function render(s){
    s=s.trim();
    if(s[0]==='√'){
      var root=el('msqrt');root.appendChild(render(inner(s.slice(1).trim())));return root;
    }
    s=inner(s);
    // Nested radicals within a numerator or denominator, e.g. (1 + √3)/2.
    var rx=new RegExp(radical,'g'), match, last=0, row=el('mrow');
    while((match=rx.exec(s))){
      var text=el('mtext');text.textContent=s.slice(last,match.index);row.appendChild(text);
      row.appendChild(render(match[0]));last=rx.lastIndex;
    }
    var tail=el('mtext');tail.textContent=s.slice(last);row.appendChild(tail);return row;
  }
  function build(a,b,root,original,combo,n,k){
    var m=el('math');m.setAttribute('class','math-inline');m.setAttribute('aria-label',original);m.setAttribute('display','inline');
    if(combo){var sub=el('msubsup'), base=el('mi'), below=el('mn'), above=el('mn');base.textContent=combo;below.textContent=n;above.textContent=k;sub.append(base,below,above);m.appendChild(sub)}
    else if(root)m.appendChild(render(root));
    else {var f=el('mfrac');f.appendChild(render(a));f.appendChild(render(b));m.appendChild(f)}
    return m;
  }
  function convert(node){
    var str=node.nodeValue;if(!str || !/[\/√]|\b[CA]\(\d+,\d+\)/.test(str))return;
    var frag=document.createDocumentFragment(), last=0,m,changed=false;expression.lastIndex=0;
    while((m=expression.exec(str))){
      var start=m.index,end=start+m[0].length,prev=str[start-1]||'',next=str[end]||'';
      // Never reinterpret portions of words, slash chains, dates, percentages/units, or pasted URLs.
      if((prev && ((!m[3] && letter.test(prev))||prev==='/'||prev==='√')) || (next && (letter.test(next)||next==='/')) ||
         (m[3] && /^√\s*\d+[a-zA-Z]$/.test(m[3])) ||
         (m[1] && /^(?:sin|cos|tan|cot)\s*[a-zA-Z]$/.test(m[1]) && /^\d+$/.test(m[2])) ||
         (m[2] && (str.slice(0,start).match(/\b(?:https?:|www\.)[^\s]*$/) || /^\s*(?:năm|tháng|ngày|giờ|phút|tuần|điểm|bài)\b/i.test(str.slice(end)) && /^\d+$/.test(m[1]) && /^\d+$/.test(m[2]))))continue;
      frag.appendChild(document.createTextNode(str.slice(last,start)));frag.appendChild(build(m[1],m[2],m[3],m[0],m[4],m[5],m[6]));last=end;changed=true;
    }
    if(changed){frag.appendChild(document.createTextNode(str.slice(last)));node.replaceWith(frag)}
  }
  function scan(root){
    if(!root || root.nodeType!==1)return;
    var list=[];
    if(root.matches(targets))list.push(root);
    root.querySelectorAll(targets).forEach(function(e){list.push(e)});
    list.forEach(function(container){
      var walker=document.createTreeWalker(container,NodeFilter.SHOW_TEXT,{acceptNode:function(n){
        if(n.parentElement.closest('math,script,style,textarea,input,button,code,pre,.meta,.tag,.t,.n,.lbl,.hint,summary,a'))return NodeFilter.FILTER_REJECT;
        return /[\/√]|\b[CA]\(\d+,\d+\)/.test(n.nodeValue)?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT;
      }}), nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);nodes.forEach(convert);
    });
  }
  scan(document.body);
  var observer=new MutationObserver(function(changes){
    changes.forEach(function(c){c.addedNodes.forEach(function(n){if(n.nodeType===1 && n.namespaceURI!=='http://www.w3.org/1998/Math/MathML'){var parent=n.closest(targets);if(parent)scan(parent);else scan(n)}else if(n.nodeType===3 && n.parentElement && n.parentElement.namespaceURI!=='http://www.w3.org/1998/Math/MathML'){var parent=n.parentElement.closest(targets);if(parent)scan(parent)}})});
  });
  observer.observe(document.body,{childList:true,subtree:true});
})();
